﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using RAM.FileName;

namespace RAM.FileName
{
    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    internal class CommandFillNames : IExternalCommand
    {
        public List<FamilyInstance> TitleBlockList = new List<FamilyInstance>(); //список выбранных листов основной надписи

        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            Document doc = commandData.Application.ActiveUIDocument.Document; //Получаем открытый проект

            List<string> ListSheets = new List<string>();//Инициализируем список для названия листов

            //Собираем список семейства Основной надписи
            List<FamilyInstance> TitleBlocksList = new FilteredElementCollector(doc)
                .OfCategory(BuiltInCategory.OST_TitleBlocks)
                .WhereElementIsNotElementType()
                .Cast<FamilyInstance>()
                .Where(f => f.LookupParameter("ADSK_Штамп_1 фамилия") != null)
                .ToList();

            //Собираем в список сведения о проекте
            List<ProjectInfo> ListprojectInfo = new FilteredElementCollector(doc)
                .OfCategory(BuiltInCategory.OST_ProjectInformation)
                .Cast<ProjectInfo>()
                .ToList();

            //Собираем список листов в проекте
            List<ViewSheet> ViewSheetsList = new FilteredElementCollector(doc)
                    .OfClass(typeof(ViewSheet))
                    .Cast<ViewSheet>()
                    .OrderBy(vs => vs.Name)
                    .Where(f => f.LookupParameter("Имя листа").AsString() != "Начальный вид")
                    .ToList();

            //Объявляем класс формы

            FormFillNames form1 = new FormFillNames(ViewSheetsList, doc);

            //Заполняем должности в параметрах формы в соответствии с параметрами расположенными в сведениях о проекте
            form1.surLabel1 = ListprojectInfo[0].LookupParameter("ADSK_Штамп_1 должность").AsString();
            form1.surLabel2 = ListprojectInfo[0].LookupParameter("ADSK_Штамп_2 должность").AsString();
            form1.surLabel3 = ListprojectInfo[0].LookupParameter("ADSK_Штамп_3 должность").AsString();
            form1.surLabel4 = ListprojectInfo[0].LookupParameter("ADSK_Штамп_4 должность").AsString();
            form1.surLabel5 = ListprojectInfo[0].LookupParameter("ADSK_Штамп_5 должность").AsString();
            form1.surLabel6 = ListprojectInfo[0].LookupParameter("ADSK_Штамп_6 должность").AsString();

            form1.ShowDialog();

            if (form1.DialogResult != System.Windows.Forms.DialogResult.OK)
            {
                return Result.Cancelled;
            }

            List<ViewSheet> SelViewSheet = form1.SelViewSheet; //список для элементов полученых через ViewSheet

            for (int i = 0; i < SelViewSheet.Count; i++)
            {
                //Получаем список Основных надписей размещенных на выбраных листах
                List<FamilyInstance> l1 = new FilteredElementCollector(doc, SelViewSheet[i].Id)
                    .OfCategory(BuiltInCategory.OST_TitleBlocks)
                    .WhereElementIsNotElementType().Cast<FamilyInstance>()
                    .ToList();

                TitleBlockList.AddRange(l1);
            }

            using (Transaction t = new Transaction(doc))
            {
                t.Start("Заполнение штампа");

                //Проходимся по каждому листу и в параметр ADSK_Штамп_1 фамилия записываем значение из формы
                foreach (FamilyInstance titleBlock in TitleBlockList)
                {
                    if (titleBlock.LookupParameter("ADSK_Штамп_1 фамилия") != null) //Проверяем каждое семейство  штампа на наличие параметра
                    {
                        titleBlock.LookupParameter("ADSK_Штамп_1 фамилия").Set(form1.Surname1);
                    }
                    if (titleBlock.LookupParameter("ADSK_Штамп_2 фамилия") != null) //Проверяем каждое семейство  штампа на наличие параметра
                    {
                        titleBlock.LookupParameter("ADSK_Штамп_2 фамилия").Set(form1.Surname2);
                    }
                    if (titleBlock.LookupParameter("ADSK_Штамп_3 фамилия") != null) //Проверяем каждое семейство  штампа на наличие параметра
                    {
                        titleBlock.LookupParameter("ADSK_Штамп_3 фамилия").Set(form1.Surname3);
                    }
                    if (titleBlock.LookupParameter("ADSK_Штамп_4 фамилия") != null) //Проверяем каждое семейство  штампа на наличие параметра
                    {
                        titleBlock.LookupParameter("ADSK_Штамп_4 фамилия").Set(form1.Surname4);
                    }
                    if (titleBlock.LookupParameter("ADSK_Штамп_5 фамилия") != null) //Проверяем каждое семейство  штампа на наличие параметра
                    {
                        titleBlock.LookupParameter("ADSK_Штамп_5 фамилия").Set(form1.Surname5);
                    }
                    if (titleBlock.LookupParameter("ADSK_Штамп_6 фамилия") != null) //Проверяем каждое семейство  штампа на наличие параметра
                    {
                        titleBlock.LookupParameter("ADSK_Штамп_6 фамилия").Set(form1.Surname6);
                    }

                }
                t.Commit();
            }

            return Result.Succeeded;


        }
    }
}
