﻿namespace RAM.FileName
{
    partial class FormFillNames
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox_Surname1 = new System.Windows.Forms.TextBox();
            this.SurLabel1 = new System.Windows.Forms.Label();
            this.textBox_Surname2 = new System.Windows.Forms.TextBox();
            this.SurLabel2 = new System.Windows.Forms.Label();
            this.SurLabel5 = new System.Windows.Forms.Label();
            this.SurLabel4 = new System.Windows.Forms.Label();
            this.SurLabel3 = new System.Windows.Forms.Label();
            this.textBox_Surname5 = new System.Windows.Forms.TextBox();
            this.textBox_Surname4 = new System.Windows.Forms.TextBox();
            this.textBox_Surname3 = new System.Windows.Forms.TextBox();
            this.ListBox = new System.Windows.Forms.CheckedListBox();
            this.btn_ОК = new System.Windows.Forms.Button();
            this.textBox_Surname6 = new System.Windows.Forms.TextBox();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.Calendar = new System.Windows.Forms.DateTimePicker();
            this.DateCheck = new System.Windows.Forms.CheckBox();
            this.checkBoxVisSign = new System.Windows.Forms.CheckBox();
            this.SurLb6 = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // textBox_Surname1
            // 
            this.textBox_Surname1.Location = new System.Drawing.Point(12, 32);
            this.textBox_Surname1.Multiline = true;
            this.textBox_Surname1.Name = "textBox_Surname1";
            this.textBox_Surname1.Size = new System.Drawing.Size(96, 23);
            this.textBox_Surname1.TabIndex = 0;
            // 
            // SurLabel1
            // 
            this.SurLabel1.AutoSize = true;
            this.SurLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.SurLabel1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.SurLabel1.Location = new System.Drawing.Point(14, 13);
            this.SurLabel1.Name = "SurLabel1";
            this.SurLabel1.Size = new System.Drawing.Size(76, 16);
            this.SurLabel1.TabIndex = 9;
            this.SurLabel1.Text = "Фамилия 1";
            // 
            // textBox_Surname2
            // 
            this.textBox_Surname2.Location = new System.Drawing.Point(12, 86);
            this.textBox_Surname2.Multiline = true;
            this.textBox_Surname2.Name = "textBox_Surname2";
            this.textBox_Surname2.Size = new System.Drawing.Size(96, 23);
            this.textBox_Surname2.TabIndex = 10;
            // 
            // SurLabel2
            // 
            this.SurLabel2.AutoSize = true;
            this.SurLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.SurLabel2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.SurLabel2.Location = new System.Drawing.Point(14, 67);
            this.SurLabel2.Name = "SurLabel2";
            this.SurLabel2.Size = new System.Drawing.Size(76, 16);
            this.SurLabel2.TabIndex = 11;
            this.SurLabel2.Text = "Фамилия 2";
            // 
            // SurLabel5
            // 
            this.SurLabel5.AutoSize = true;
            this.SurLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.SurLabel5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.SurLabel5.Location = new System.Drawing.Point(14, 226);
            this.SurLabel5.Name = "SurLabel5";
            this.SurLabel5.Size = new System.Drawing.Size(76, 16);
            this.SurLabel5.TabIndex = 16;
            this.SurLabel5.Text = "Фамилия 5";
            // 
            // SurLabel4
            // 
            this.SurLabel4.AutoSize = true;
            this.SurLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.SurLabel4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.SurLabel4.Location = new System.Drawing.Point(14, 171);
            this.SurLabel4.Name = "SurLabel4";
            this.SurLabel4.Size = new System.Drawing.Size(76, 16);
            this.SurLabel4.TabIndex = 17;
            this.SurLabel4.Text = "Фамилия 4";
            // 
            // SurLabel3
            // 
            this.SurLabel3.AutoSize = true;
            this.SurLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.SurLabel3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.SurLabel3.Location = new System.Drawing.Point(14, 119);
            this.SurLabel3.Name = "SurLabel3";
            this.SurLabel3.Size = new System.Drawing.Size(76, 16);
            this.SurLabel3.TabIndex = 18;
            this.SurLabel3.Text = "Фамилия 3";
            // 
            // textBox_Surname5
            // 
            this.textBox_Surname5.Location = new System.Drawing.Point(12, 245);
            this.textBox_Surname5.Multiline = true;
            this.textBox_Surname5.Name = "textBox_Surname5";
            this.textBox_Surname5.Size = new System.Drawing.Size(96, 23);
            this.textBox_Surname5.TabIndex = 15;
            // 
            // textBox_Surname4
            // 
            this.textBox_Surname4.Location = new System.Drawing.Point(13, 188);
            this.textBox_Surname4.Multiline = true;
            this.textBox_Surname4.Name = "textBox_Surname4";
            this.textBox_Surname4.Size = new System.Drawing.Size(96, 23);
            this.textBox_Surname4.TabIndex = 14;
            // 
            // textBox_Surname3
            // 
            this.textBox_Surname3.Location = new System.Drawing.Point(13, 138);
            this.textBox_Surname3.Multiline = true;
            this.textBox_Surname3.Name = "textBox_Surname3";
            this.textBox_Surname3.Size = new System.Drawing.Size(96, 23);
            this.textBox_Surname3.TabIndex = 13;
            // 
            // ListBox
            // 
            this.ListBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ListBox.CheckOnClick = true;
            this.ListBox.FormattingEnabled = true;
            this.ListBox.Location = new System.Drawing.Point(171, 13);
            this.ListBox.Name = "ListBox";
            this.ListBox.Size = new System.Drawing.Size(120, 334);
            this.ListBox.TabIndex = 12;
            this.ListBox.SelectedIndexChanged += new System.EventHandler(this.ListBox_SelectedIndexChanged);
            // 
            // btn_ОК
            // 
            this.btn_ОК.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_ОК.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btn_ОК.Location = new System.Drawing.Point(216, 460);
            this.btn_ОК.Name = "btn_ОК";
            this.btn_ОК.Size = new System.Drawing.Size(75, 23);
            this.btn_ОК.TabIndex = 19;
            this.btn_ОК.Text = "ОК";
            this.btn_ОК.UseVisualStyleBackColor = true;
            this.btn_ОК.Click += new System.EventHandler(this.btn_ОК_Click);
            // 
            // textBox_Surname6
            // 
            this.textBox_Surname6.Location = new System.Drawing.Point(12, 301);
            this.textBox_Surname6.Multiline = true;
            this.textBox_Surname6.Name = "textBox_Surname6";
            this.textBox_Surname6.Size = new System.Drawing.Size(96, 23);
            this.textBox_Surname6.TabIndex = 15;
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_Cancel.Location = new System.Drawing.Point(17, 460);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(75, 23);
            this.btn_Cancel.TabIndex = 20;
            this.btn_Cancel.Text = "Отмена";
            this.btn_Cancel.UseVisualStyleBackColor = true;
            this.btn_Cancel.Click += new System.EventHandler(this.btn_Cancel_Click);
            // 
            // Calendar
            // 
            this.Calendar.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Calendar.Location = new System.Drawing.Point(17, 363);
            this.Calendar.Name = "Calendar";
            this.Calendar.Size = new System.Drawing.Size(100, 20);
            this.Calendar.TabIndex = 23;
            this.Calendar.Value = new System.DateTime(2023, 3, 6, 0, 0, 0, 0);
            // 
            // DateCheck
            // 
            this.DateCheck.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.DateCheck.AutoSize = true;
            this.DateCheck.Location = new System.Drawing.Point(17, 425);
            this.DateCheck.Name = "DateCheck";
            this.DateCheck.Size = new System.Drawing.Size(105, 17);
            this.DateCheck.TabIndex = 22;
            this.DateCheck.Text = "Заполнить дату";
            this.DateCheck.UseVisualStyleBackColor = true;
            this.DateCheck.CheckedChanged += new System.EventHandler(this.DateCheck_CheckedChanged);
            // 
            // checkBoxVisSign
            // 
            this.checkBoxVisSign.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.checkBoxVisSign.AutoSize = true;
            this.checkBoxVisSign.Checked = true;
            this.checkBoxVisSign.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxVisSign.Location = new System.Drawing.Point(17, 397);
            this.checkBoxVisSign.Name = "checkBoxVisSign";
            this.checkBoxVisSign.Size = new System.Drawing.Size(127, 17);
            this.checkBoxVisSign.TabIndex = 21;
            this.checkBoxVisSign.Text = "Видимость подписи";
            this.checkBoxVisSign.UseVisualStyleBackColor = true;
            this.checkBoxVisSign.CheckedChanged += new System.EventHandler(this.checkBoxVisSign_CheckedChanged);
            // 
            // SurLb6
            // 
            this.SurLb6.AutoSize = true;
            this.SurLb6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.SurLb6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.SurLb6.Location = new System.Drawing.Point(15, 282);
            this.SurLb6.Name = "SurLb6";
            this.SurLb6.Size = new System.Drawing.Size(76, 16);
            this.SurLb6.TabIndex = 16;
            this.SurLb6.Text = "Фамилия 6";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(171, 396);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(85, 17);
            this.radioButton1.TabIndex = 24;
            this.radioButton1.Text = "radioButton1";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // FormFillNames
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(303, 495);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.Calendar);
            this.Controls.Add(this.DateCheck);
            this.Controls.Add(this.checkBoxVisSign);
            this.Controls.Add(this.btn_Cancel);
            this.Controls.Add(this.btn_ОК);
            this.Controls.Add(this.SurLb6);
            this.Controls.Add(this.SurLabel5);
            this.Controls.Add(this.SurLabel4);
            this.Controls.Add(this.SurLabel3);
            this.Controls.Add(this.textBox_Surname6);
            this.Controls.Add(this.textBox_Surname5);
            this.Controls.Add(this.textBox_Surname4);
            this.Controls.Add(this.textBox_Surname3);
            this.Controls.Add(this.ListBox);
            this.Controls.Add(this.SurLabel2);
            this.Controls.Add(this.textBox_Surname2);
            this.Controls.Add(this.SurLabel1);
            this.Controls.Add(this.textBox_Surname1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "FormFillNames";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Заполнить штамп";
            this.Load += new System.EventHandler(this.FormFillNames_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_Surname1;
        private System.Windows.Forms.Label SurLabel1;
        private System.Windows.Forms.TextBox textBox_Surname2;
        private System.Windows.Forms.Label SurLabel2;
        private System.Windows.Forms.Label SurLabel5;
        private System.Windows.Forms.Label SurLabel4;
        private System.Windows.Forms.Label SurLabel3;
        private System.Windows.Forms.TextBox textBox_Surname5;
        private System.Windows.Forms.TextBox textBox_Surname4;
        private System.Windows.Forms.TextBox textBox_Surname3;
        private System.Windows.Forms.CheckedListBox ListBox;
        private System.Windows.Forms.Button btn_ОК;
        private System.Windows.Forms.TextBox textBox_Surname6;
        private System.Windows.Forms.Button btn_Cancel;
        private System.Windows.Forms.DateTimePicker Calendar;
        private System.Windows.Forms.CheckBox DateCheck;
        private System.Windows.Forms.CheckBox checkBoxVisSign;
        private System.Windows.Forms.Label SurLb6;
        private System.Windows.Forms.RadioButton radioButton1;
    }
}